﻿namespace GameLibrary.TimeAwareness
{
    public interface IAgeAwareness
    {
        int Age { get; }
    }
}
