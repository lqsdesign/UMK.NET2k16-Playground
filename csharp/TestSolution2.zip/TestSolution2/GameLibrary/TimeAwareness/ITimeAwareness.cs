﻿namespace GameLibrary.TimeAwareness
{
    public interface ITimeAwareness
    {
        void ElapsedDays(int daysCount);
    }
}
